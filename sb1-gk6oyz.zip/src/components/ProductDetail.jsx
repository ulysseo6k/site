import { useParams } from 'react-router-dom';
import { useCart } from './CartContext';
import { newMotos, occasionMotos } from '../data/motos';

export default function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();
  
  const moto = [...newMotos, ...occasionMotos].find(m => m.id === parseInt(id));

  if (!moto) {
    return <div className="container mx-auto px-4 py-8">Moto non trouvée</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="md:flex">
          <div className="md:w-1/2">
            <img 
              src={moto.image} 
              alt={moto.name} 
              className="w-full h-[400px] object-cover"
            />
          </div>
          <div className="md:w-1/2 p-8">
            <h1 className="text-3xl font-bold mb-4">{moto.name}</h1>
            <p className="text-gray-600 mb-4">{moto.description}</p>
            <div className="text-3xl font-bold text-red-600 mb-6">
              {moto.price} €
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-2">Caractéristiques</h2>
              <div className="grid grid-cols-2 gap-4">
                {Object.entries(moto.specs).map(([key, value]) => (
                  <div key={key} className="bg-gray-50 p-3 rounded">
                    <span className="font-semibold capitalize">{key}:</span> {value}
                  </div>
                ))}
              </div>
            </div>
            
            <p className="text-gray-700 mb-6">{moto.details}</p>
            
            <button
              onClick={() => addToCart(moto)}
              className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition"
            >
              Ajouter au panier
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}