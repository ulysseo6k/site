import { useCart } from './CartContext';
import { XMarkIcon } from '@heroicons/react/24/outline';

export default function Cart() {
  const { cart, removeFromCart, getTotal } = useCart();

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Votre Panier</h1>
      
      {cart.length === 0 ? (
        <p className="text-gray-600">Votre panier est vide</p>
      ) : (
        <div className="space-y-4">
          {cart.map((item) => (
            <div key={item.id} className="flex items-center justify-between bg-white p-4 rounded-lg shadow">
              <div className="flex items-center space-x-4">
                <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded" />
                <div>
                  <h3 className="font-bold">{item.name}</h3>
                  <p className="text-gray-600">{item.price} €</p>
                </div>
              </div>
              <button
                onClick={() => removeFromCart(item.id)}
                className="text-red-600 hover:text-red-800"
              >
                <XMarkIcon className="h-6 w-6" />
              </button>
            </div>
          ))}
          
          <div className="mt-8 bg-white p-4 rounded-lg shadow">
            <div className="flex justify-between items-center mb-4">
              <span className="font-bold">Total:</span>
              <span className="text-2xl font-bold">{getTotal()} €</span>
            </div>
            <button className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition">
              Procéder au paiement
            </button>
          </div>
        </div>
      )}
    </div>
  );
}