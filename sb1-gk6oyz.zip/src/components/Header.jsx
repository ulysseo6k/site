import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Bars3Icon as MenuIcon, XMarkIcon, ShoppingBagIcon as ShoppingCartIcon } from '@heroicons/react/24/outline';
import { useCart } from './CartContext';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { cart } = useCart();

  return (
    <header className="bg-black text-white shadow-lg">
      <nav className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link to="/" className="text-2xl font-bold">MotoShop.fr</Link>
          
          <div className="hidden md:flex space-x-8">
            <Link to="/" className="hover:text-gray-300">Accueil</Link>
            <Link to="/motos" className="hover:text-gray-300">Nos Motos</Link>
            <Link to="/occasions" className="hover:text-gray-300">Occasions</Link>
            <Link to="/contact" className="hover:text-gray-300">Contact</Link>
          </div>

          <div className="flex items-center space-x-4">
            <Link to="/panier" className="relative">
              <ShoppingCartIcon className="h-6 w-6 hover:text-gray-300" />
              {cart.length > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </Link>
            <button 
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <XMarkIcon className="h-6 w-6" />
              ) : (
                <MenuIcon className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <Link to="/" className="block hover:text-gray-300">Accueil</Link>
            <Link to="/motos" className="block hover:text-gray-300">Nos Motos</Link>
            <Link to="/occasions" className="block hover:text-gray-300">Occasions</Link>
            <Link to="/contact" className="block hover:text-gray-300">Contact</Link>
          </div>
        )}
      </nav>
    </header>
  );
}