import { Link } from 'react-router-dom';
import { useCart } from './CartContext';

export default function ProductCard({ moto }) {
  const { addToCart } = useCart();

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition transform hover:-translate-y-1">
      <img 
        src={moto.image} 
        alt={moto.name} 
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-bold mb-2">{moto.name}</h3>
        <p className="text-gray-600 mb-2">{moto.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold text-red-600">{moto.price} €</span>
          <div className="space-x-2">
            <Link 
              to={`/moto/${moto.id}`}
              className="bg-black text-white px-4 py-2 rounded hover:bg-gray-800"
            >
              Voir détails
            </Link>
            <button 
              onClick={() => addToCart(moto)}
              className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
            >
              Ajouter
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}