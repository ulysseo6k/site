export const newMotos = [
  {
    id: 1,
    name: "Yamaha MT-07",
    description: "Roadster dynamique et polyvalent",
    price: 7499,
    image: "https://images.unsplash.com/photo-1558981359-219d6364c9c8?auto=format&fit=crop&q=80",
    specs: {
      puissance: "73.4 ch",
      cylindree: "689 cc",
      poids: "184 kg",
      hauteurSelle: "805 mm"
    },
    details: "La Yamaha MT-07 est un roadster polyvalent qui offre des sensations de conduite exceptionnelles. Son moteur CP2 de 689 cc délivre un couple puissant pour une conduite dynamique en ville comme sur route."
  },
  {
    id: 2,
    name: "Kawasaki Ninja 650",
    description: "Sportive accessible et performante",
    price: 7999,
    image: "https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&q=80",
    specs: {
      puissance: "68 ch",
      cylindree: "649 cc",
      poids: "196 kg",
      hauteurSelle: "790 mm"
    },
    details: "La Ninja 650 combine le style sportif emblématique de Kawasaki avec une position de conduite confortable. Parfaite pour les trajets quotidiens et les virées du week-end."
  },
  {
    id: 3,
    name: "Honda CB650R",
    description: "Néo-rétro sophistiquée",
    price: 8299,
    image: "https://images.unsplash.com/photo-1558981001-1995369a39cd?auto=format&fit=crop&q=80",
    specs: {
      puissance: "95 ch",
      cylindree: "649 cc",
      poids: "202 kg",
      hauteurSelle: "810 mm"
    },
    details: "La CB650R incarne le style néo-rétro moderne de Honda avec des performances de premier ordre. Son quatre cylindres en ligne offre une sonorité unique et des performances exceptionnelles."
  }
];

export const occasionMotos = [
  {
    id: 101,
    name: "Ducati Monster 821 2019",
    description: "Excellent état, 12 000 km",
    price: 8990,
    image: "https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?auto=format&fit=crop&q=80",
    specs: {
      puissance: "109 ch",
      cylindree: "821 cc",
      kilometrage: "12 000 km",
      annee: "2019"
    },
    details: "Cette Ducati Monster 821 de 2019 est en excellent état. Entretien complet réalisé, pneus récents. Historique complet disponible."
  },
  {
    id: 102,
    name: "BMW R1250GS 2020",
    description: "Parfait état, tous les extras",
    price: 15990,
    image: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?auto=format&fit=crop&q=80",
    specs: {
      puissance: "136 ch",
      cylindree: "1254 cc",
      kilometrage: "25 000 km",
      annee: "2020"
    },
    details: "BMW R1250GS Adventure avec pack confort et dynamique. Valises d'origine, protection moteur, GPS."
  }
];