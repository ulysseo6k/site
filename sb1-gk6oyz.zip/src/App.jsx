import { Routes, Route } from 'react-router-dom';
import { CartProvider } from './components/CartContext';
import Header from './components/Header';
import Hero from './components/Hero';
import FeaturedProducts from './components/FeaturedProducts';
import OccasionsList from './components/OccasionsList';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';

function App() {
  return (
    <CartProvider>
      <div className="min-h-screen">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={
              <>
                <Hero />
                <FeaturedProducts />
              </>
            } />
            <Route path="/motos" element={<FeaturedProducts />} />
            <Route path="/occasions" element={<OccasionsList />} />
            <Route path="/moto/:id" element={<ProductDetail />} />
            <Route path="/panier" element={<Cart />} />
            <Route path="/contact" element={<div className="container mx-auto px-4 py-8"><h1 className="text-2xl font-bold">Contact</h1></div>} />
          </Routes>
        </main>
      </div>
    </CartProvider>
  );
}

export default App;